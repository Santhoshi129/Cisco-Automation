package com.example.cisco_automation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
